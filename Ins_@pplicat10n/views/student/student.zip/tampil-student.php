<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Latihan CRUD</title>
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>

<div class="container">
	<h1>Latihan CRUD</h1>

	<a href="data/add" class="btn btn-primary">Tambah Data Karyawan</a>

	<table class="table">
		<thead>
			<tr>
				<th>#</th>
				<th>Nama Student</th>
				<th>Alamat</th>
				<th>Email</th>
				<th></th>
			</tr>
		</thead>
		<tbody>
				<tr>
					<td><?php echo $default['id_user']; ?></td>
					<td><?=isset($default['nama_lengkap'])? $default['nama_lengkap'] : ""?></td>
					<td><input type="text" class="form-control" name="nama" value="<?=isset($default['nama_lengkap'])? $default['nama_lengkap'] : ""?>"></td>
					<td><?=isset($default['username'])? $default['username'] : ""?></td>
					<td>
						<a href='#' class='btn btn-sm btn-info'>Update</a>
						<a href='#' class='btn btn-sm btn-danger'>Hapus</a>
					</td>
				</tr>
		</tbody>
	</table>
</div>
	
</body>
</html>