<!DOCTYPE html>
<html lang="en">
 <head>
  <title>codeigniterexamplesDisplay Records From Database Using Codeigniter</title>
  <link href="<?= base_url();?>css/bootstrap.css" rel="stylesheet">
 </head>
 <body>
  <div class="row">
   <div style="width:600px;margin:50px;">
    <h4>Join Table Example Using Codeigniter</h4>
     <table>
     <?php foreach($STUDENT as $student){?>
     <tr>
     	<td><?=$student->username;?></td>
     	<td><?=$student->nama_lengkap;?></td>
     	<td><?=$student->flag;?></td>
     </tr>     
     <?php }?>  
    </table>
   </div> 
  </div> 
 </body>
</html>